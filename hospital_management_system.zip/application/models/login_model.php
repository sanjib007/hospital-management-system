<?php

class Login_model extends CI_Model {
    public $id;
    public $fname;
    public $lname;
    public $birthday;
    public $occupation;
    public $email;
    public $mobile;
    public $present_address;
    public $permanent_address;
    public $type;
    public $password;
    public $status;
    public $join_date;
    public function getAAdmin(){
        $query = $this->db->get_where('admin_user', array('email' => $this->email,'password'=>$this->password));
        if($query->num_rows() > 0){
            return $query->row();
        }
        else{
            return false;
        }
    }
    public function getAUserInfo() {
        $this->db->where('id', $this->id); 
        $query = $this->db->get('admin_user');
        return $query->row();
    }
}
